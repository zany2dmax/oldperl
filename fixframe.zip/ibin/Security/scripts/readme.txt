Fixiframe should be run with the following:

fixiframe.pl [drive:path] {>> iframe.log}

	The drive letter and path are required.

	The output log is optional.   

	The script requires "grep" to be in c:\ibin (c:\ibin\grep).

Note: This script will only look for "npanetwork".  If that link should change, then the script will need to be modified as well.