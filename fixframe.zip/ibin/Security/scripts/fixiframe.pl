use File::Find ;

# In order to use this you must call perl: c:\perl\bin\perl fixiframe.pl [Hostname] [Directory] >> [log]
# Change $debug to = 1 in order to activate debug function. This is for use on servers that have been massively defaced.

$Debug = 0;
$pattern = "npanetwork" ;

sub PrintIfHacked {

  print "Attempting to open $File::Find::name.\n" if $Debug ;
  return if -d ;
  return if /badfile/ ; 
  if (/htm/ or /html/ or /asp/ or /cfm/) {

   if (not open FILE, $File::Find::name) {
     print "Failed to open $FILE::Find::name.\n" if $Debug ;
     return ;
   } ;
  }
  else {
  return;
  }; 
  $just_the_filename = $_ ;
  while (<FILE>) {
    if (/$pattern/o) {
      
      $cleanedpath = $File::Find::name ;
      $cleanedpath =~ s!\/!\\!g ;
      #$cleanedpath =~ s!E\:!! ; 
      $cleanedpath =~ s!\\\\!\\! ; 
      close (FILE) ; 
      print "rename $cleanedpath $just_the_filename.badfile\n" ;
      system "rename $cleanedpath $just_the_filename.badfile" ; 
      system "c:\\ibin\\grep -v npanetwork $cleanedpath.badfile > $cleanedpath" ;
      
      last ;
    } ;
  } ;
  close (FILE) ;
} ;

print "The following output was created with a search against $pattern.\n" ; 
# $hostname = shift ; 
# print $hostname ; 
while ($dir = shift) {
  find (\&PrintIfHacked, $dir) ;
} ;




